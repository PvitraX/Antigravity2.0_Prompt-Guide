# 💰 Cost Saving Tips — Don't Burn Your Antigravity Budget

> Antigravity 2.0 uses **compute-based billing** that refreshes every 5 hours (not daily prompt limits like before). Managed Agents bills per run, not per token. Here's how to stay efficient.

---

## The New Billing Model

| Tier | Cost | Usage |
|------|------|-------|
| Free | $0 | Limited compute, 5hr refresh |
| AI Pro | $20/mo | Standard compute |
| AI Ultra | $100/mo | 5x Pro limits + priority |
| Pay-as-you-go | Top-up credits | Any tier, when you hit limits |

**Key insight:** Managed Agents bills per *run*, not per token. A long agent run that makes 10,000 model requests costs the same billing unit as one that makes 10. **Design for fewer, smarter runs.**

---

## Rule 1 — Cap Subagent Depth. Always.

Dynamic subagents can spawn subagents. Without a depth limit, a single prompt can cascade into dozens of agents, each burning compute.

```json
{
  "hook": "before_subagent_spawn",
  "condition": "subagent.depth >= 2",
  "action": "block"
}
```

Set this in `.agents/hooks.json` and forget about it. It'll save you.

---

## Rule 2 — Cache Aggressively

Repeated context across runs = wasted money. Use Gemini's context caching for any content you send repeatedly (system prompts, large files, docs).

Gemini 3.5 Flash pricing: `$0.50 per million input tokens` — but context caching cuts repeated-token costs by up to **90%**.

For scheduled tasks that read the same files every time:

```
Before analyzing /docs/architecture.md, check if a cached summary 
exists at /tmp/arch-cache.md (created today). If it exists, use that 
instead of re-reading the full document.
```

---

## Rule 3 — Write Idempotent Scheduled Tasks

Cron-style scheduled tasks can misfire and run twice. If your task isn't idempotent, you'll pay double and get corrupt state.

**Bad:**
```
Append today's metrics to /reports/metrics.csv
```

**Good:**
```
Write today's metrics to /reports/metrics-{{date}}.csv. 
If the file already exists and is non-empty, skip and log "already ran today".
```

---

## Rule 4 — Scope Subagents Tightly

A vague subagent prompt = the agent explores more than it needs to, burning compute. Be surgical.

**Bad:**
```
Subagent 1: Improve the codebase
```

**Good:**
```
Subagent 1: Add TypeScript types to all .ts files in /src/lib that 
currently have 'any' type annotations. Do not touch files outside /src/lib.
```

---

## Rule 5 — Use the CLI for Quick Tasks

The Antigravity Desktop App is great for orchestration — but for quick one-off tasks (run a lint, check a file, explain an error), use the CLI. It's lighter weight and faster to spin up.

```bash
agy "explain the error in @src/api/auth.ts line 42"
```

Save the Desktop App for multi-agent workflows that need visual oversight.

---

## Rule 6 — Don't Use Agents for Simple Tasks

Agents are powerful but they have overhead. For tasks a simple script can do, use a script.

| Use an agent for | Use a script for |
|------------------|-----------------|
| Multi-step reasoning | File renaming |
| Cross-file refactors | Running tests |
| Research + implement | Formatting code |
| Complex debugging | Bumping version numbers |

---

## Rule 7 — Voice for Short, Text for Long

Voice input is faster for short prompts. For long, multi-step specs, dictation is error-prone and you'll waste a run correcting misheard instructions.

- **Voice:** "Fix the type error on line 24" ✅
- **Text:** Full 10-step refactor specification ✅
- **Voice:** 10-step refactor specification ❌ (just type it)

---

## Estimated Compute Cost Guide

| Task Type | Estimated Compute Cost |
|-----------|----------------------|
| Single-file fix | Very low |
| Full feature build (1 agent) | Medium |
| Parallel subagent task (3 agents) | Medium-high |
| Full codebase audit | High |
| Scheduled daily digest | Low (per run) |
| Build OS from scratch with 93 subagents | Ultra only 💀 |
