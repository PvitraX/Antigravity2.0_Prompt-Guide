# Antigravity CLI Prompts (`agy`)

> Terminal-first prompts for the Antigravity CLI — the direct successor to Gemini CLI.

Install: `curl -fsSL https://antigravity.google/install.sh | bash`  
Authenticate: `agy auth login`

---

## Slash Commands Cheat Sheet

| Command | Description |
|---------|-------------|
| `/agent <task>` | Dispatch a long-running task to a background subagent |
| `/browser` | Open a Chrome debug session — agent validates UI changes |
| `agy inspect` | Show loaded config files, skills, plugins, agent state |
| `agy run <schedule>` | Trigger a scheduled task manually |

---

## 1. Inspect Your Project First (Always Do This)

```bash
agy inspect
```

Shows:
- Config files loaded (`.agents/`, `AGENTS.md`)
- Agent Skills available globally and per-workspace
- Plugins loaded (including migrated Gemini CLI extensions)

**Do this before every new project session.** Saves you from debugging why the agent ignores your instructions.

---

## 2. Background Subagent — Long Refactor

```bash
/agent refactor "Convert all callback-based handlers in @internal/api 
to use async/await. Report a summary diff when done."
```

Agent runs in background. Keep prompting in foreground. Result appears in status bar when done.

---

## 3. Parallel Subagents — Split a Big Task

```
Start 3 parallel subagents:
- Subagent 1: audit /src for any console.log statements and remove them
- Subagent 2: check all API routes in /pages/api for missing error handling, add try/catch
- Subagent 3: scan /components for any hardcoded color values, replace with Tailwind classes

Report when all three are complete with a file-change summary.
```

---

## 4. Browser Validation — End-to-End UI Check

```
/browser

Navigate to localhost:3000/checkout.
Fill in the checkout form with test data.
Verify the order confirmation page loads correctly.
Screenshot any error states you find and report them.
```

> Use `/browser` explicitly when you need UI validation. Don't rely on the agent to decide when to browse — it won't always get it right.

---

## 5. Git Hook Integration

```
Set up a pre-commit hook that:
- Runs ESLint on staged files
- If lint errors exist, auto-fix them with --fix
- If unfixable errors remain, block the commit and print the errors

Write the hook to .git/hooks/pre-commit and make it executable.
```

---

## 6. CI Pipeline Task

```
Run as a CI step:
1. Install dependencies (npm ci)
2. Run tests (npm test)
3. If tests pass, build (npm run build)
4. If build passes, output a JSON summary: { status, testCount, buildSize, duration }
5. If anything fails, exit with code 1 and print the error

Do not continue past a failing step.
```

---

## 7. Migrate from Gemini CLI

If you used Gemini CLI Extensions, they're now Antigravity Plugins.

```bash
# Check what Gemini CLI extensions you had
agy inspect --legacy

# Import them as Antigravity plugins
agy plugin import ~/.gemini/extensions/<name>
```

Preserved from Gemini CLI:
- ✅ Agent Skills
- ✅ Hooks
- ✅ Subagents
- ✅ Extensions → now called Plugins

---

## Tips for CLI Prompts

- **Be explicit about files.** Use `@filename` syntax to reference files directly.
- **Set depth limits.** Add "max subagent depth: 2" to avoid recursive agent explosions.
- **Use `agy inspect` before starting.** Know what skills and plugins are loaded.
- **Voice for short commands, text for long specs.** Dictating a 10-step refactor plan is painful.
