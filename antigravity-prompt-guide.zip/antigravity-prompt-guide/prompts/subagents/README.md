# Subagent Prompt Patterns

> Parallel agent patterns for Antigravity 2.0 — split work, run fast, keep context clean.

---

## Why Subagents?

Single-agent setups are sequential and context-polluting. Subagents solve both:

- ⚡ **Speed** — tasks run in parallel, not one after another
- 🧠 **Clean context** — each subagent gets its own focused window, no reasoning degradation
- 🎯 **Specialization** — each agent is scoped to exactly what it needs to know

---

## Pattern 1 — The Parallel Specialist

Split one big task into specialist lanes.

```
Split this task across 3 specialist subagents running in parallel:

Subagent 1 (Backend): 
  - Design the database schema for a blog platform (users, posts, tags, comments)
  - Write the Prisma schema file
  - Generate the migration

Subagent 2 (API):
  - Build REST API routes: GET/POST/PUT/DELETE for posts and comments
  - Add input validation with Zod
  - Add auth middleware (JWT)

Subagent 3 (Tests):
  - Write integration tests for every API route
  - Use supertest + Jest
  - Include happy path and error cases

Merge all outputs into the /src directory when all three finish.
```

---

## Pattern 2 — The Research + Build Pipeline

One agent researches, one builds.

```
Run 2 sequential subagents:

Subagent 1 (Research):
  Research the best approach for adding full-text search to a Next.js + Postgres app in 2026.
  Compare: pg_trgm, pgvector semantic search, and Typesense.
  Output a markdown decision doc at /docs/search-decision.md with a clear recommendation.

Subagent 2 (Build) — runs after Subagent 1 completes:
  Read /docs/search-decision.md.
  Implement the recommended approach in our app.
  Add a /api/search route, update the UI search bar in /components/SearchBar.tsx,
  and write 3 tests.
```

---

## Pattern 3 — The Code Review Panel

Multiple reviewers, one codebase.

```
Run 3 parallel code review subagents on /src:

Subagent 1 (Security):
  Scan for: SQL injection risks, unvalidated inputs, exposed secrets, 
  insecure API endpoints. Report findings with file + line number.

Subagent 2 (Performance):
  Scan for: N+1 queries, missing indexes, unoptimized React renders,
  large bundle imports. Report with estimated impact (high/medium/low).

Subagent 3 (Accessibility):
  Scan all /components for: missing aria labels, keyboard navigation issues,
  color contrast problems, missing alt text. Report with WCAG 2.1 reference.

Compile all three reports into /docs/code-review-[date].md.
```

---

## Pattern 4 — The Daily Digest Agent (Scheduled)

```json
{
  "name": "daily-digest",
  "schedule": "0 9 * * *",
  "prompt": "Check: (1) open GitHub issues labeled 'bug' created in last 24h, (2) failed CI runs in the last 24h, (3) any Sentry errors with >10 occurrences. Write a digest to /reports/daily-[date].md and post a Slack summary to #dev-alerts.",
  "max_subagent_depth": 1
}
```

> ⚠️ Always set `max_subagent_depth` on scheduled tasks. Without it, recursive subagents will drain your compute budget before the 5-hour refresh.

---

## Pattern 5 — The Migration Agent

```
Migrate this Express.js codebase to Hono (edge-compatible):

Use subagents to parallelize by route file:
- Each subagent handles one file in /routes/
- Convert Express syntax to Hono equivalents
- Preserve all middleware logic
- Update imports

Run up to 5 subagents in parallel.
After all files are converted, run a final subagent to:
- Update package.json dependencies
- Update the main server entry point
- Run the test suite and fix any failures

Report total files changed and any issues.
```

---

## ⚠️ Subagent Guardrails

| Rule | Why |
|------|-----|
| Always set `max_subagent_depth` | Dynamic subagents can spawn subagents — without a cap, you'll recurse into budget oblivion |
| Design scheduled tasks for idempotency | Cron tasks can misfire and run twice. Make them safe to run multiple times |
| Don't spawn >10 parallel subagents | Compute refreshes every 5 hours. Parallel isn't free |
| Scope each subagent tightly | Vague subagent instructions = overlapping work and merge conflicts |
