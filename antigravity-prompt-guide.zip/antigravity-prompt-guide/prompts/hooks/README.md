# JSON Hooks — Control Agent Behavior at Lifecycle Stages

> Hooks intercept what Antigravity 2.0 does *before* it does it. Use them to add guardrails, require approvals, log actions, or trigger custom logic.

---

## Hook Lifecycle Stages

```
prompt received
      ↓
  [before_tool_call]    ← intercept before any tool runs
      ↓
  tool executes
      ↓
  [after_tool_call]     ← inspect or log tool output
      ↓
  [before_file_write]   ← intercept before any file is modified
      ↓
  file written
      ↓
  [on_error]            ← catch failures, retry or alert
      ↓
  [on_complete]         ← run cleanup or notify on success
```

---

## Hook 1 — Require Approval Before Writing Critical Files

```json
{
  "hook": "before_file_write",
  "condition": "file.path.startsWith('/src/critical') || file.path === 'package.json'",
  "action": "require_approval",
  "message": "Agent wants to modify a critical file: {{file.path}}. Approve?"
}
```

---

## Hook 2 — Block Writes to Production Config

```json
{
  "hook": "before_file_write",
  "condition": "file.path.includes('.env.production') || file.path.includes('terraform/')",
  "action": "block",
  "message": "Production config changes are not allowed via agent. Make this change manually."
}
```

---

## Hook 3 — Log Every Tool Call

```json
{
  "hook": "after_tool_call",
  "action": "append_to_file",
  "target": "./logs/agent-audit-{{date}}.log",
  "format": "[{{timestamp}}] Tool: {{tool.name}} | Input: {{tool.input}} | Status: {{tool.status}}"
}
```

Good for auditing what the agent actually did during a long session.

---

## Hook 4 — Auto-run Tests After Any File Change

```json
{
  "hook": "after_file_write",
  "condition": "file.path.startsWith('/src') && file.path.endsWith('.ts')",
  "action": "run_command",
  "command": "npm test -- --testPathPattern={{file.path}}",
  "on_failure": "alert_agent"
}
```

If tests fail after an agent edit, the agent is notified and can self-correct.

---

## Hook 5 — Slack Alert on Agent Error

```json
{
  "hook": "on_error",
  "action": "run_command",
  "command": "curl -X POST $SLACK_WEBHOOK -d '{\"text\": \"Antigravity agent error in {{project}}: {{error.message}}\"}'",
  "condition": "error.severity === 'critical'"
}
```

---

## Hook 6 — Cap Subagent Depth (Prevent Budget Drain)

```json
{
  "hook": "before_subagent_spawn",
  "condition": "subagent.depth >= 2",
  "action": "block",
  "message": "Subagent depth limit reached. Complete current tasks before spawning more agents."
}
```

> This is the most important hook for cost control. Always include it.

---

## Hook 7 — Clean Up Temp Files on Complete

```json
{
  "hook": "on_complete",
  "action": "run_command",
  "command": "rm -rf ./tmp/agent-workspace-*",
  "condition": "session.exitCode === 0"
}
```

---

## Combining Hooks — Full Safety Config

Drop this in `.agents/hooks.json` for a safe default setup:

```json
[
  {
    "hook": "before_file_write",
    "condition": "file.path.includes('.env') || file.path.includes('terraform/')",
    "action": "block",
    "message": "Blocked: production config files are off-limits."
  },
  {
    "hook": "before_subagent_spawn",
    "condition": "subagent.depth >= 2",
    "action": "block",
    "message": "Max subagent depth reached."
  },
  {
    "hook": "after_tool_call",
    "action": "append_to_file",
    "target": "./logs/agent-audit.log",
    "format": "[{{timestamp}}] {{tool.name}}: {{tool.status}}"
  },
  {
    "hook": "on_error",
    "condition": "error.severity === 'critical'",
    "action": "require_approval",
    "message": "Critical error: {{error.message}}. Continue?"
  }
]
```

---

## Tips

- Hooks are evaluated in order. Put `block` hooks first.
- Use `condition` to be surgical — hooks that fire on every action slow things down.
- `run_command` hooks run in the same sandbox as the agent. Don't give them more permissions than needed.
- Test hooks with a dry run before using them in production scheduled tasks.
