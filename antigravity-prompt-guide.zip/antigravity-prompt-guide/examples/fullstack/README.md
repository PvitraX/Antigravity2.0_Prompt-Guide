# Full-Stack App Build Prompts

> End-to-end prompts for building complete applications with Antigravity 2.0.

---

## 1. SaaS Starter (Next.js + Supabase + Stripe)

```
Build a full-stack SaaS boilerplate with the following stack:
- Next.js 15 (App Router, TypeScript)
- Supabase (auth + PostgreSQL database)
- Stripe (subscriptions — monthly and annual plans)
- Tailwind CSS + shadcn/ui components
- Vercel deployment config

Create:
1. Auth flow: signup, login, password reset, email verification
2. Dashboard layout with sidebar navigation
3. Billing page: show current plan, upgrade/downgrade, cancel
4. Stripe webhook handler for subscription events
5. Middleware to protect all /dashboard routes
6. Environment variables template (.env.example)
7. Setup README with step-by-step instructions

Use 2 subagents in parallel:
- Subagent 1: backend (Supabase schema, API routes, Stripe webhooks)
- Subagent 2: frontend (pages, components, auth UI)

Merge when both complete. Run the dev server and confirm it starts without errors.
```

---

## 2. REST API with Full Test Suite

```
Build a production-ready REST API for a task management app:

Stack: Node.js, Hono, PostgreSQL (via Drizzle ORM), Zod validation, JWT auth

Endpoints:
- POST /auth/register, POST /auth/login, POST /auth/refresh
- GET/POST /tasks, GET/PUT/DELETE /tasks/:id
- GET/POST /projects, GET/PUT/DELETE /projects/:id
- GET /tasks?projectId=&status=&assignee= (filtered list)

For each endpoint:
- Input validation with Zod
- Proper HTTP status codes
- Error messages in { error: string } format
- Auth middleware where required

Also create:
- Drizzle schema + migration
- Integration tests with supertest (happy path + 3 error cases each)
- OpenAPI spec (openapi.json)
- Docker Compose for local Postgres

Run tests before finishing. Fix any failures before reporting done.
```

---

## 3. AI-Powered Feature Addition

```
Add an AI-powered code review feature to our existing Next.js app.

Context: We have a Next.js 15 app with Supabase auth. Users can submit code snippets.

Feature requirements:
1. New page: /review — code editor (use CodeMirror) + submit button
2. API route: POST /api/review
   - Accept: { code: string, language: string }
   - Call Gemini API to review the code for: bugs, security issues, performance
   - Return: { issues: Issue[], score: number, summary: string }
3. Results display: show issues grouped by severity (error/warning/info)
4. Save review history to Supabase (table: code_reviews)
5. History page: /review/history — paginated list of past reviews

Type: Issue = { severity: 'error'|'warning'|'info', line: number, message: string, suggestion: string }

Add GEMINI_API_KEY to .env.example.
Write tests for the API route.
Do not modify the existing auth flow.
```

---

## 4. Real-Time Feature (WebSockets)

```
Add real-time collaborative editing to our existing app.

Current stack: Next.js 15, Supabase, TypeScript.

Requirements:
1. Users can join a "room" by ID
2. All users in a room see each other's cursor positions in real-time
3. Text edits sync within 100ms
4. Presence indicator: show avatars of who's currently in the room
5. Disconnect handling: gracefully remove user from room on tab close

Implementation:
- Use Supabase Realtime (already in our stack, no new services)
- Create a useRoom() hook that handles subscription and cleanup
- Add a /room/[id] page that uses the hook
- Show a demo with 2 browser windows side by side in your final report

Keep all new code in /src/features/rooms/.
Write tests for the hook using mock Supabase client.
```

---

## 5. The "Build This Screenshot" Prompt

*Pair this with an uploaded screenshot of a UI you want to clone.*

```
Look at the uploaded screenshot.

Build a pixel-accurate implementation of this UI using:
- Next.js 15 + TypeScript
- Tailwind CSS (match colors exactly — use custom config if needed)
- All interactive elements should work (buttons, dropdowns, modals)
- Use realistic placeholder data (not "Lorem ipsum")
- Make it responsive: desktop (1440px), tablet (768px), mobile (375px)

Create all components in /src/components/[feature-name]/.
Export a default page component from /src/app/[route]/page.tsx.

Run the dev server and use /browser to screenshot your result.
Compare it to the original and fix any major visual differences.
```
